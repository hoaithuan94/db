# Sinh viên tiến hành chạy file DB.sql để lấy dữ liệu trước khi thực hiện các yêu cầu tiếp theo

USE DB;

# Cho biết mã giáo viên của những giáo viên có lương >= 2500 hoặc có người thân là nam 
SELECT magv 
FROM GiaoVien
WHERE luong >= 2500
UNION
SELECT magv 
FROM NguoiThan
WHERE phai = 'Nam';


# Bài tập 
-- 1. Cho biết mã đề tài có giáo viên tham gia với họ là 'Trần' hoặc người chủ nhiệm đề tài có họ là 'Trần'.
-- 2. Cho biết những đề tài nào được bắt đầu làm trong năm 2018 hoặc kết thúc trong năm 2020.
-- 3. Cho biết mã giáo viên của những giáo viên có tham gia đề tài hoặc có mức lương trên 2000.
-- 4. Cho biết những bộ môn nào thuộc khoa có mã là CNTT hoặc HH.
-- 5. Cho biết những giáo viên nào có địa chỉ nhà ở HCM hoặc TP Tân An.



