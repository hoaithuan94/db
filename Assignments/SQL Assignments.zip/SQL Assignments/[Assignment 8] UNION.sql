# Sinh viên tiến hành chạy file DB.sql để lấy dữ liệu trước khi thực hiện các yêu cầu tiếp theo

USE DB;

# Cho biết mã giáo viên của những giáo viên có lương >= 2500 hoặc có người thân là nam 
SELECT magv 
FROM GiaoVien
WHERE luong >= 2500
UNION
SELECT magv 
FROM NguoiThan
WHERE phai = 'Nam';


# Bài tập 
-- 1. Cho biết mã đề tài có giáo viên tham gia với họ là 'Trần' 
-- hoặc người chủ nhiệm đề tài có họ là 'Trần'.




