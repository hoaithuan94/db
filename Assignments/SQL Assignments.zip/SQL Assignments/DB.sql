
-- 1/ Tạo DB + Sử dụng DB
	CREATE DATABASE IF NOT EXISTS DB;
    
	USE DB;
	
-- 2/ Tạo bảng + Khoá chính
	CREATE TABLE GiaoVien
	(
		magv CHAR(3),
		hoten VARCHAR(50),
		luong FLOAT,
		phai CHAR(3),
		ngsinh DATE,
		diachi VARCHAR(50),
		gvqlcm CHAR(3),
		mabm CHAR(4),
		PRIMARY KEY(magv)
	);
    
	CREATE TABLE BoMon
	(
		mabm CHAR(4),
		tenbm VARCHAR(50),
		phong CHAR(3),
		dienthoai CHAR(11),
		truongbm CHAR(3),
		makhoa CHAR(4),
		ngaynhanchuc DATE,
		PRIMARY KEY(mabm)
	);
    
	CREATE TABLE Khoa
	(
		makhoa CHAR(4),
		tenkhoa VARCHAR(50),
		namtl INT,
		phong CHAR(3),
		dienthoai CHAR(10),
		truongkhoa CHAR(3),
		ngaynhanchuc DATE,
		PRIMARY KEY(makhoa)
	);
	
    CREATE TABLE ChuDe
	(
		macd CHAR(4),
		tencd VARCHAR(30),
		PRIMARY KEY(macd)
	);
    
	CREATE TABLE DeTai
	(
		madt CHAR(4),
		tendt VARCHAR(100),
		capql VARCHAR(20),
		kinhphi FLOAT,
		ngaybd DATE,
		ngaykt DATE,
		macd CHAR(4),
		gvcndt CHAR(3),
		PRIMARY KEY(madt)
	);
    
	CREATE TABLE CongViec 
	(
		madt CHAR(4),
		stt INT,
		tencv VARCHAR(50),
		ngaybd DATE,
		ngaykt DATE,
		PRIMARY KEY(madt,stt)
	);
	
	CREATE TABLE ThamGiaDT
	(
		magv CHAR(3),
		madt CHAR(4),
		stt INT,
		phucap FLOAT,
		ketqua VARCHAR(10),
		PRIMARY KEY(magv,madt,stt)
	);
    
	CREATE TABLE GV_DT
	(
		magv CHAR(3),
		dienthoai CHAR(10),
		PRIMARY KEY(magv,dienthoai)
	);
    
	CREATE TABLE NguoiThan
	(
		magv CHAR(3),
		ten VARCHAR(12),
		ngsinh DATE,
		phai CHAR(3),
		PRIMARY KEY(magv,ten)
	);
	
-- 3/ Tạo khoá ngoại

#Tạo khóa ngoại ở bảng GiaoVien
	ALTER TABLE GiaoVien
		ADD CONSTRAINT fk1_gvqlcm 
        FOREIGN KEY (gvqlcm)
		REFERENCES GiaoVien(magv);
        
	ALTER TABLE GiaoVien
		ADD CONSTRAINT fk2_mabm
		FOREIGN KEY (mabm)
		REFERENCES BoMon(mabm);

#Tạo khóa ngoại ở bảng BoMon
	ALTER TABLE BoMon
		ADD CONSTRAINT fk3_truongbm
		FOREIGN KEY (truongbm)
		REFERENCES GiaoVien(magv);
        
	ALTER TABLE BoMon
		ADD CONSTRAINT fk4_makhoa
		FOREIGN KEY (makhoa)
		REFERENCES Khoa(makhoa);
     
#Tạo khóa ngoại ở bảng Khoa
	ALTER TABLE Khoa
		ADD CONSTRAINT fk5_truongkhoa
		FOREIGN KEY (truongkhoa)
		REFERENCES GiaoVien(magv);
     
	
#Tạo khóa ngoại ở bảng DeTai
	ALTER TABLE DeTai
		ADD CONSTRAINT fk6_macd
		FOREIGN KEY (macd)
		REFERENCES ChuDe(macd);
		
	ALTER TABLE DeTai
		ADD CONSTRAINT fk7_gvcndt
		FOREIGN KEY (gvcndt)
		REFERENCES GiaoVien(magv);
     
#Tạo khóa ngoại ở bảng CongViec
	ALTER TABLE CongViec
		ADD CONSTRAINT fk8_madt
		FOREIGN KEY (madt)
		REFERENCES DeTai(madt);
        
        
#Tạo khoá ngoại ở bảng ThamGiaDT
	ALTER TABLE ThamGiaDT
		ADD CONSTRAINT fk9_magv
		FOREIGN KEY (magv)
		REFERENCES GiaoVien(magv);
        
	ALTER TABLE ThamGiaDT
		ADD CONSTRAINT fk10_madt
		FOREIGN KEY (madt, stt)
		REFERENCES CongViec(madt,stt);
	
#Tạo khóa ngoại ở bảng GV_DT
	ALTER TABLE GV_DT
		ADD CONSTRAINT fk11_magv
		FOREIGN KEY (magv)
		REFERENCES GiaoVien(magv);
        
#Tạo khóa ngoại ở bảng NguoiThan
	ALTER TABLE NguoiThan
		ADD CONSTRAINT fk12_magv
		FOREIGN KEY (magv)
		REFERENCES GiaoVien(magv);
        
	

		
-- 4/ Nhập data
#Nhập data cho bảng GiaoVien
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi)
	VALUES ('001','Nguyễn Hoài An',2000.0,'Nam','1983-02-15','25/3 Lạc Long Quân, Q.10, TP HCM');
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi)
	VALUES ('002','Trần Trà Hương',2500.0,'Nữ','1994-06-20','125 Trần Hưng Đạo, Q.1, TP HCM');
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi,gvqlcm)
	VALUES ('003','Nguyễn Ngọc Ánh',2200.0,'Nữ','1975-05-11','12/21 Võ Văn Ngân Thủ Đức, TP HCM','002');
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi)
	VALUES ('004','Trương Nam Sơ',2300.0,'Nam','1999-06-20','215 Lý Thường Kiệt,TP Biên Hòa');
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi)
	VALUES ('005','Lý Hoàng Hà',2600.0,'Nam','1970-10-23','22/5 Nguyễn Xí, Q.Bình Thạnh, TP HCM');
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi,gvqlcm)
	VALUES ('006','Trần Bạch Tuyết',1500.0,'Nữ','1989-05-20','127 Hùng Vương, Q.5, TP HCM','004');
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi)
	VALUES ('007','Nguyễn An Trung',2100.0,'Nam','1990-06-05','234 3/2, TP Biên Hòa');
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi,gvqlcm)
	VALUES ('008','Trần Trung Hiếu',1800.0,'Nam','1977-08-06','22/11 Lý Thường Kiệt,TP Mỹ Tho','007');
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi,gvqlcm)
	VALUES ('009','Trần Hoàng nam',2000.0,'Nam','1975-11-22','178 Phạm Văn Hai, TP Tân An','001');
	INSERT INTO GiaoVien(magv,hoten,luong,phai,ngsinh,diachi,gvqlcm)
	VALUES ('010','Phạm Nam Thanh',1500.0,'Nam','1980-12-12','221 Hùng Vương, Q.5, TP HCM','007');
	


#Nhập data cho bảng Khoa
	INSERT INTO Khoa VALUES 
    ('CNTT','Công nghệ thông tin',1995,'B11','0838123456','002','2015-02-20'),
	('HH','Hóa học',1982,'B41','0838456456','007','2011-10-15'),
	('TH','Toán học',1982,'B31','0838454545','004','2020-10-11'),
	('VL','Vật lý',1976,'B21','0838223223','005','2013-09-18');
	

#Nhập data cho bảng BoMon
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,makhoa)
	VALUES ('CNTT','Công nghệ tri thức','B15','0838126126','CNTT');
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,makhoa)
	VALUES ('HHC','Hóa hữu cơ','B44','0838222222','HH');
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,makhoa)
	VALUES ('CH','Cơ học','B42','0838878787','VL');
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,truongbm,makhoa,ngaynhanchuc)
	VALUES ('HPT','Hóa phân tích','B43','0838777777','007','HH','2017-10-15');
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,truongbm,makhoa,ngaynhanchuc)
	VALUES ('HTTT','Hệ thống thông tin','B13','0838125125','002','CNTT','2014-09-20');
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,truongbm,makhoa,ngaynhanchuc)
	VALUES ('MMT','Mạng máy tính','B16','0838676767','001','CNTT','2015-05-15');
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,makhoa)
	VALUES ('TUD','Toán ứng dụng','B33','0838898989','TH');
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,makhoa)
	VALUES ('VLĐT','Vật lý điện tử','B23','0838234234','VL');
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,truongbm,makhoa,ngaynhanchuc)
	VALUES ('KTPM','Kỹ thuật phần mềm','B24','0838454545','005','CNTT','2016-02-18');
	INSERT INTO BoMon(mabm,tenbm,phong,dienthoai,truongbm,makhoa,ngaynhanchuc)
	VALUES ('TT','Toán tin','B32','0838909090','004','TH','2017-01-01');
	


    
#Nhập data cho bảng ChuDe
	INSERT INTO ChuDe VALUES 
    ('NCPT', 'Nghiên cứu phát triển'),
	('QLGD', 'Quản lý giáo dục'),
	('UDCN', 'Ứng dụng công nghệ');
	
#Nhập data cho bảng DeTai
	INSERT INTO DeTai VALUES 
    ('001','HTTT quản lý các trường ĐH','ĐHQG',200.0,'2017-10-20','2018-10-20','QLGD','002'),
	('002','HTTT quản lý giáo vụ cho một Khoa','Trường',60.0,'2020-10-12','2021-10-12','QLGD','002'),
    ('003','Nghiên cứu phương pháp tối ưu bài toán xấp xỉ đa thức','ĐHQG',100.0,'2018-10-10','2020-05-15','NCPT','005'),
	('004','Tạo vật liệu mới ứng dụng trong xây dựng công trình','Nhà nước',100.0,'2017-01-01','2019-12-31','NCPT','004'),
	('005','Ứng dụng hóa học xanh','Trường',200.0,'2018-10-10','2020-12-10','UDCN','007'),
	('006','Nghiên cứu chuyển động của hệ mặt trời','Nhà nước',4000.0,'2016-10-12','2019-10-12','NCPT','004'),
	('007','HTTT quản lý thư viện ở các trường ĐH','Trường',90.0,'2019-05-10','2020-05-10','QLGD','001');
	
#Nhập data cho bảng CongViec
	INSERT INTO CongViec VALUES 
    ('001',1,'Khởi tạo và Lập kế hoạch','2017-10-20','2018-12-20'),
	('001',2,'Xác định yêu cầu','2018-12-21','2018-03-21'),
	('001',3,'Phân tích hệ thống','2018-03-22','2018-05-22'),
	('001',4,'Thiết kế hệ thống','2018-05-23','2018-06-23'),
	('001',5,'Cài đặt thử nghiệm','2018-06-24','2018-10-20'),
	('002',1,'Khởi tạo và lập kế hoạch','2019-05-10','2019-07-10'),
	('002',2,'Xác định yêu cầu','2019-07-11','2019-10-11'),
	('002',3,'Phân tích hệ thống','2019-10-12','2019-12-20'),
	('002',4,'Thiết kế hệ thống','2019-12-21','2020-03-22'),
	('002',5,'Cài đặt thử nghiệm','2020-03-23','2020-05-10'),
	('006',1,'Chế tạo sản phẩm','2016-10-20','2017-02-20'),
	('006',2,'Nghiên cứu Khoa học','2017-02-21','2018-09-21');
	
	
#Nhập data cho bảng ThamGiaDT
	INSERT INTO ThamGiaDT VALUES 
    ('001','002',1,0.0,NULL),
    ('001','002',2,2.0,NULL),
    ('002','001',4,2.0,'Đạt'),
    ('003','001',1,1.0,'Đạt'),
    ('003','001',2,0.0,'Đạt'),
    ('003','001',4,1.0,'Đạt'),
    ('003','002',2,0.0, NULL),
    ('004','006',1,2.5,'Đạt'),
    ('004','006',2,1.0,'Đạt'),
    ('006','006',2,1.5,'Đạt'),
    ('009','002',3,0.5, NULL),
    ('009','002',4,1.5, NULL);
	

#Nhập data cho bảng GV_DT
	INSERT INTO GV_DT VALUES
	('001','0838912019'),
    ('001','0903532088'),
    ('002','0956462907'),
    ('003','0838151075'),
    ('003','0903530968'),
    ('003','0937125609'),
    ('006','0937860731'),
    ('008','0653707189'),
    ('008','0913214201');
	
	
#Nhập data cho bảng NguoiThan
	INSERT INTO NguoiThan VALUES 
    ('001','Hùng','1990-01-14','Nam'),
    ('001','Thủy','1994-12-08','Nữ'),
    ('003','Hà','1998-09-03','Nữ'),
    ('003','Thu','1998-09-03','Nữ'),
    ('007','Mai','2003-03-26','Nữ'),
    ('007','Vy','2000-02-14','Nữ'),
    ('008','Nam','1991-05-06','Nam'),
    ('009','An','1996-08-19','Nam'),
    ('010','Nguyệt','2016-01-14','Nữ');
	
	

#Cập nhật thêm dữ liệu cho bảng GiaoVien
	UPDATE GiaoVien SET mabm = 'MMT'  WHERE magv = '001';
	UPDATE GiaoVien SET mabm = 'HTTT' WHERE magv = '002';
	UPDATE GiaoVien SET mabm = 'HTTT' WHERE magv = '003';
	UPDATE GiaoVien SET mabm = 'CH'   WHERE magv = '004';
	UPDATE GiaoVien SET mabm = 'VLĐT' WHERE magv = '005';
	UPDATE GiaoVien SET mabm = 'TT'   WHERE magv = '006';
	UPDATE GiaoVien SET mabm = 'KTPM' WHERE magv = '007';
	UPDATE GiaoVien SET mabm = 'HPT'  WHERE magv = '008';
	UPDATE GiaoVien SET mabm = 'MMT'  WHERE magv = '009';
    UPDATE GiaoVien SET mabm = 'TUD'  WHERE magv = '010';
