# Sinh viên tiến hành chạy file DB.sql để lấy dữ liệu trước khi thực hiện các yêu cầu tiếp theo

USE DB;

# Các hàm này được sử dụng trong mệnh đề SELECT hoặc HAVING
# Không dùng cho WHERE

# Tính tổng lương, lương lớn nhất, lương nhỏ nhất và lương trung bình của toàn bộ giáo viên
SELECT SUM(luong), MAX(luong), MIN(luong), AVG(luong)
FROM GiaoVien;

# Cho biết số lượng giáo viên
SELECT COUNT(*)
FROM GiaoVien


# Bài tập 
-- 1. Tính tổng lương, lương lớn nhất, lương nhỏ nhất và lương trung bình
-- của giáo viên thuộc bộ môn 'Hệ thống thông tin'
-- 2. Cho biết số lượng giáo viên ở bộ môn 'Hệ thống thông tin'
-- 3. Cho biết số lượng các mức lương của giáo viên (không tính giá trị lương bị trùng)
-- 4. Cho biết có bao nhiêu giáo viên có từ 2 người thân trở lên.
-- 5. Cho biết có bao nhiêu giáo viên đạt kết quả đề tài.

