# Sinh viên tiến hành chạy file DB.sql để lấy dữ liệu trước khi thực hiện các yêu cầu tiếp theo

USE DB;

# Ví dụ 1. Tạo Trigger thêm giáo viên
# Tạo trigger
DELIMITER //  
CREATE TRIGGER them_GiaoVien
AFTER INSERT
ON GiaoVien FOR EACH ROW
BEGIN
	INSERT INTO GV_DT(magv, dienthoai) VALUES (NEW.magv, '0392654310');
END 
//

INSERT INTO GiaoVien (magv, hoten, luong, phai, ngsinh, diachi, gvqlcm, mabm)
VALUES ('012','Lê Minh Đức', 2100, 'Nam','1994-10-01','153 Nguyễn Trãi, Q.5, TP HCM', NULL, 'HTTT');

# Xoá trigger
#DROP TRIGGER them_GiaoVien;


# Bài tập 
-- 1. Tạo trigger khi thêm hoặc chỉnh sửa dữ liệu của bảng giáo viên thì cột tuoi (tuổi)sẽ được tính theo công thức tuoi = năm hiện tại - năm sinh.
-- 2. Tạo trigger khi thêm một giáo viên thì mặc định để người đó tham gia đề tài có mã là 001.
