# Sinh viên tiến hành chạy file DB.sql để lấy dữ liệu trước khi thực hiện các yêu cầu tiếp theo

USE DB;

-- Dùng đặt bí danh (alias) cho cột, bảng

# Đổi tên cột hiển thị
SELECT mabm AS 'Mã môn', tenbm 'Tên môn' 
FROM BoMon;

# Cho biết mã giáo viên, họ tên và lương của họ sau khi tăng lên 10%
SELECT magv, hoten, luong*1.1 
FROM GiaoVien;

# Cho biết mã giáo viên, họ tên và lương của họ sau khi tăng lên 10%
SELECT magv AS 'Mã GV', hoten AS 'Họ tên', luong*1.1 AS 'Lương Tăng 10%' 
FROM GiaoVien;

# Cho biết mã giáo viên, họ tên giáo viên thuộc bộ môn 'Hệ thống thông tin'
SELECT gv.magv, gv.hoten
FROM GiaoVien AS gv, BoMon AS bm
WHERE gv.mabm = bm.mabm 
	  AND bm.tenbm = 'Hệ thống thông tin' ;

# Bài tập 
-- 1. Đổi tên cột makhoa thành 'Mã khoa' và tenkhoa thành 'Tên khoa'
-- 2. Cho biết mã giáo viên, họ tên giáo viên và họ tên người quản lý chuyên môn giáo viên nếu có
-- 3. Cho biết mã giáo viên, họ tên giáo viên và tên người thân tương ứng
-- 4. Cho biết danh sách các giáo viên có tham gia đề tài
-- 5. Cho biết danh sách các giáo viên là chủ nhiệm đề tài
