# Sinh viên tiến hành chạy file DB.sql để lấy dữ liệu trước khi thực hiện các yêu cầu tiếp theo

USE DB;


SELECT *
FROM GiaoVien LEFT OUTER JOIN BoMon 
ON BoMon.mabm = GiaoVien.mabm;

# SQL cho phép viết tắt OUTER JOIN -> JOIN
SELECT *
FROM BoMon LEFT JOIN GiaoVien 
ON BoMon.mabm = GiaoVien.mabm;
-- Record nào bảng phải không có thì để null
-- Record nào bảng trái không có thì không ghi vào


SELECT *
FROM BoMon RIGHT JOIN GiaoVien 
ON BoMon.mabm = GiaoVien.mabm;


# Cho biết mã giáo viên, họ tên giáo viên và họ tên người quản lý chuyên môn giáo viên nếu có
SELECT gv.magv, gv.hoten, qlcm.hoten 
FROM GiaoVien AS gv LEFT OUTER JOIN GiaoVien AS qlcm 
ON gv.gvqlcm = qlcm.magv;

# SQL cho phép viết tắt OUTER JOIN -> JOIN
SELECT gv.magv, gv.hoten, qlcm.hoten 
FROM GiaoVien AS gv LEFT JOIN GiaoVien AS qlcm 
ON gv.gvqlcm = qlcm.magv;



# Bài tập 
-- 1. Cho biết mã giáo viên, họ tên giáo viên và tên đề tài của họ tham gia nếu có.


